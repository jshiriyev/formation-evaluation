from . import onepage

from ._read import read
from ._load import load